## Income Growth

In this project, I'll practice creating Shiny apps with more complex layouts and content elements:

![Example income growth chart](img/example.png)
